package case_spe;

public class Mort {

}
