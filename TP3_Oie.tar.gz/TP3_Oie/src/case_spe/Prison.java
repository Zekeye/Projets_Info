package case_spe;

public class Prison {

}
