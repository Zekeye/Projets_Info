/**
 * 
 */
package case_spe;
import jeu.*;

/**
 * @author sbf3676a
 *
 */
public class Faste extends Case {
	public Faste(int numCase) {
		super(numCase);
		// TODO Stub du constructeur généré automatiquement
	}


	private Case cases[]= new Case[6];

	/**
	 * @param cases
	 */

	
	public Faste ActionFaste(Case cases) {
		
	}
	
	
	public Case arrivee(Oie oieEnJeu) {
		String arrivee_faste=super.arrivee(oieEnJeu);
		System.out.println(arrivee_faste+"\nelle tombe sur une case fast et rejoue !");
	}
}
