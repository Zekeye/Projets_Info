/**
 * 
 */
package case_spe;

/**
 * @author sbf3676a
 *
 */
public class Puits {

}
