/**
 * 
 */
package jeu;
import case_spe.*;

/**
 * @author sbf3676a
 *
 */
public class Plateau {
	private int nb_cases=64;
	private Case cases[]= new Case[nb_cases];
	/**
	 * 
	 */
	public Plateau() {
		super();
		
		for (int i=0;i<nb_cases;i++) {
			cases[i]=new Case(i);
			initialisationCasesSpecifique(cases[i]);
			
		}
	}
	
	public Case donnerCase(int numCase) {
		return cases[numCase]; 		
	}
	
	public Case caseDebutPartie() {
		return cases[0];
	}
	
	private Case initialisationCasesSpecifique(Case cases) {
		Case case_spe=cases;
		
		if(donnerCase(9)==case_spe || donnerCase(18)==case_spe || donnerCase(27)==case_spe || donnerCase(36)==case_spe || donnerCase(45)==case_spe || donnerCase(54)==case_spe) {
			case_spe = new Faste().numCase;
		}
	
		if(donnerCase(6)==case_spe) {
	
		}
		
		if(donnerCase(19)==case_spe) {
		}
		
		if(donnerCase(31)==case_spe) {
			
		}
		
		if(donnerCase(42)==case_spe) {
			
		}
		
		if(donnerCase(52)==case_spe) {
			
		}
		
		if(donnerCase(58)==case_spe) {
		}
		
		if(donnerCase(63)==case_spe) {
			case_spe=null;
		}
		return case_spe;
	}
}
