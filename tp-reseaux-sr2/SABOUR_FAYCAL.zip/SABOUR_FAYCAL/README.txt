V4 non fonctionnelle

