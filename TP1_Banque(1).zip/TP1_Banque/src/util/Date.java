/**
 * 
 */
package util;

/**
 * @author sbf3676a
 *
 */
public class Date {
	private int jour;
	private int mois;
	private int an;
	private int heure=0;
	private int minute=0;
	private int seconde=0;
	/**
	 * @param jour
	 * @param mois
	 * @param an
	 */
	public Date(int jour, int mois, int an) {
		super();
		this.jour = jour;
		this.mois = mois;
		this.an = an;
	}
	/**
	 * @return le jour
	 */
	public int getJour() {
		return jour;
	}

	/**
	 * @return le mois
	 */
	public int getMois() {
		return mois;
	}

	/**
	 * @return le an
	 */
	public int getAn() {
		return an;
	}

	/**
	 * @return le heure
	 */
	public int getHeure() {
		return heure;
	}

	/**
	 * @return le minute
	 */
	public int getMinute() {
		return minute;
	}

	/**
	 * @return le seconde
	 */
	public int getSeconde() {
		return seconde;
	}
	
	@Override
	public String toString() {
		return "["+getHeure()+":" + getMinute() + ":" + getSeconde()+ " " + getJour() + "/" + getMois() + "/" + getAn() + "]";
	}
	
	public boolean PosterieurA(Date d) {
		if(d.an > this.an)
			return true;
		else if(d.an == this.an) {
			if(d.mois > this.mois)
				return true;
			else if(d.mois == this.mois && d.jour >= this.jour) {
				return true;
			}
			return false;
		}
		return false;
	}
}

