package test;

import banque.*;
import util.Date;

public class TestClient {

	public static void main(String[] args) {
		Client cl1 = new Client("Peter", new Date(14,02,2007));
		
		System.out.println("Nom : "+cl1.getNom());
		
		System.out.println("Date de naisssance : "+cl1.getDate());
		
		System.out.println("Compte numero : "+cl1.getCompte(0));
		
		cl1.getCompte(0).depot(100);
		
		cl1.ajouterCompte();
		
		System.out.println("Compte numero : "+cl1.getCompte(1));
		
		cl1.getCompte(1).depot(200);
		
		cl1.ajouterCompte();
		
		System.out.println("Compte numero : "+cl1.getCompte(2));
		
		cl1.getCompte(2).depot(5);
		
		cl1.afficherBilan();
		
		cl1.afficherSolde();
	}

}
