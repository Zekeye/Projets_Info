/**
 * 
 */
package test;

import util.Date;

/**
 * @author sbf3676a
 *
 */
public class TestDate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(new Date(14,02,2007));
		Date d1 = new Date(10, 02, 2021);
		System.out.println(d1);
		System.out.println(d1.toString());

	}

}
