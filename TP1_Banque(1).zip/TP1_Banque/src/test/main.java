package test;

import banque.*;
import banque.paiement.*;
import util.Date;

public class main {

	public static void main(String[] args) {
		
		System.out.println("Date :");
		System.out.println(new Date(14,02,2007));
		Date d1 = new Date(10, 02, 2021);
		Date d2 = new Date(23, 04, 2023);
		System.out.println(d1);
		System.out.println(d1.toString());
		System.out.println("");
		
		System.out.println("Compte :");
		Compte c1 = new Compte();
		Compte c2 = new Compte();
		c1.depot(500);
		c1.afficherSolde();
		c1.retrait(400);
		c1.afficherSolde();
		c1.virer(300, c2);
		System.out.println("Solde c2 :");
		c2.afficherSolde();
		System.out.println("");
		
		System.out.println("Client :");
		Client cl1 = new Client("Peter", new Date(14,02,2007));
		System.out.println("Nom : "+cl1.getNom());
		System.out.println("Date de naisssance : "+cl1.getDate());
		System.out.println("Compte numero : "+cl1.getCompte(0));
		cl1.getCompte(0).depot(100);
		cl1.ajouterCompte();
		System.out.println("Compte numero : "+cl1.getCompte(1));
		cl1.getCompte(1).depot(200);
		cl1.ajouterCompte();
		System.out.println("Compte numero : "+cl1.getCompte(2));
		cl1.getCompte(2).depot(5);
		cl1.afficherBilan();
		cl1.afficherSolde();
		System.out.println("");
		
		System.out.println("Banque :");
		Banque b = new Banque();
		System.out.println("Nouveau client : "+b.ajouterClient("Peter", new Date (14,02,2007)));
		b.getClient(0).getCompte(0).depot(100);
		b.getClient(0).ajouterCompte();
		b.getClient(0).getCompte(1).depot(200);
		System.out.println("Nouveau client : "+b.ajouterClient("Parker", new Date (04,12,2000)));
		b.getClient(1).getCompte(0).depot(300);
		b.getClient(1).ajouterCompte();
		b.getClient(1).getCompte(1).depot(400);
		b.afficherBilan();
		System.out.println("");
		
		System.out.println("Carte :");
		int[] code1 = {8,7,4,7};
		int[] code2 = {8,7,4,7};
		Carte c = new Carte(code1, new Date(20,03,2024),  b , 0, 0);
		System.out.println("code :8747 // saisie :8947 "+c.codeValide(code1));
		System.out.println("code :8747 // saisie :8747 "+c.codeValide(code2));
		System.out.println("Solde c1 initial :");
		b.getClient(0).getCompte(0).afficherSolde();
		System.out.println("Solde c2 Initiale :");
		b.getClient(1).getCompte(0).afficherSolde();
		c.payer(b, 1, 0, 500);
		System.out.println("Solde c1 :");
		b.getClient(0).getCompte(0).afficherSolde();
		System.out.println("Solde c2 :");
		b.getClient(1).getCompte(0).afficherSolde();
		b.getClient(0).getCompte(0).depot(400);
		System.out.println(b.genererAutorisation(c, 300));
		System.out.println("");
		
		System.out.println("Terminal");
		Terminal t = new Terminal(b, 1, 0);
		Carte ct = new Carte(code1, d2, b, 1, 0);
		System.out.println("Solde c1 initial :");
		b.getClient(0).getCompte(0).afficherSolde();
		System.out.println("Solde c2 initial :");
		b.getClient(1).getCompte(0).afficherSolde();
		System.out.println(t.payer(200, ct, b, 0, 0));
		System.out.println("Solde c1 initial :");
		b.getClient(0).getCompte(0).afficherSolde();
		System.out.println("Solde c2 initial :");
		b.getClient(1).getCompte(0).afficherSolde();
	}

}