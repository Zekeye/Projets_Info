package test;

import banque.Compte;


public class TestCompte {

	public static void main(String[] args) {

		Compte c1 = new Compte();
		c1.depot(500);

		c1.afficherSolde();
		
		c1.retrait(500);
		
		c1.afficherSolde();
		
		c1.virer(300, c1);
		
		c1.afficherSolde();
	}

}
