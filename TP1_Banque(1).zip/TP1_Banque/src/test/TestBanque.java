/**
 * 
 */
package test;
import banque.*;
import util.Date;

/**
 * @author fay31
 *
 */
public class TestBanque {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Banque b = new Banque();
		
        System.out.println("Nouveau client : "+b.ajouterClient("Peter", new Date (14,02,2007)));
		
		System.out.println("Client : "+b.getClient(0));
		
		
		b.afficherBilan();

	}

}
