package test;

import banque.*;
import banque.paiement.*;
import util.Date;

public class TestCarte {

	public static void main(String[] args) {
		int[] code1 = {8,7,4,7};
		int[] code2 = {8,7,4,7};
		Banque b = new Banque();
		Carte c = new Carte(code1, new Date(20,03,2024),  b , 0, 0);
		System.out.println("code :8747 // saisie :8947 "+c.codeValide(code1));
		System.out.println("code :8747 // saisie :8747 "+c.codeValide(code2));
		System.out.println("Solde c1 initial :");
		b.getClient(0).getCompte(0).afficherSolde();
		System.out.println("Solde c2 Initiale :");
		b.getClient(1).getCompte(0).afficherSolde();
		c.payer(b, 1, 0, 500);
		System.out.println("Solde c1 :");
		b.getClient(0).getCompte(0).afficherSolde();
		System.out.println("Solde c2 :");
		b.getClient(1).getCompte(0).afficherSolde();
		b.getClient(0).getCompte(0).depot(400);
		System.out.println(b.genererAutorisation(c, 300));
		
		
		
	}

}
