/**
 * 
 */
package test;

import banque.paiement.*;
import util.Date;
import banque.*;

/**
 * @author fay31
 *
 */
public class TestTerminal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Banque b= new Banque();
		int [] code1={8,4,7,4};
		Terminal t = new Terminal(b, 1, 0);
		Carte ct = new Carte(code1, new Date(24, 07, 2026), b, 1, 0);
		System.out.println("Solde c1 initial :");
		b.getClient(0).getCompte(0).afficherSolde();
		System.out.println("Solde c2 initial :");
		b.getClient(1).getCompte(0).afficherSolde();
		System.out.println(t.payer(200, ct, b, 0, 0));
		System.out.println("Solde c1 initial :");
		b.getClient(0).getCompte(0).afficherSolde();
		System.out.println("Solde c2 initial :");
		b.getClient(1).getCompte(0).afficherSolde();

	}

}
