/**
 * 
 */
package banque;

/**
 * @author sbf3676a
 *
 */
public class Compte {
	private float solde;

	public void depot(float valeur) {
		solde+=valeur;
	}

	public void retrait(float valeur) {
		if((solde-valeur)<0)
			System.out.println("Solde negatif");
		solde-=valeur;
	}

	/**
	 * @return le solde
	 */
	public float getSolde() {
		return this.solde;
	}
	
	public void afficherSolde() {
		System.out.println("Solde du compte = " +solde+" euros");
	}
	
	public void virer(float valeur, Compte destinataire) {
		if((solde-valeur)>0) {
			retrait(valeur);
			destinataire.depot(valeur);
			System.out.println("Montant vire avec succes");
		} else
			System.out.println("Virement impossible : solde negatif");
	}
}

