/**
 * 
 */
package banque;

import util.Date;

/**
 * @author sbf3676a
 *
 */
public class Client {
	private String nom;
	private Date date;
	private int nbComptes = 0;
	private Compte[] compte= new Compte [100];
	/**
	 * @param nom
	 * @param date
	 * @param nbComptes
	 */
	public Client(String nom, Date date) {
		this.nom = nom;
		this.date = date;
		compte[nbComptes] = new Compte();
		nbComptes++;
	}
	/**
	 * @return le nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @return le date
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * @return le compte
	 */
	public Compte getCompte(int numero) {
		return compte[numero];
	}

	public void afficherBilan() {
		for(int i=0; i<nbComptes; i++) {
			Compte c = getCompte(i);
			c.afficherSolde();
		}
	}

	public float soldeTotal() {
		float som = 0;
		for(int i=0; i<nbComptes; i++) {
			som+=getCompte(i).getSolde();
		}
		return som;
	}
	
	public void afficherSolde() {
		System.out.println("Solde total = "+soldeTotal()+" euros");
	}
	
	public int ajouterCompte() {
		compte[nbComptes] = new Compte();
		nbComptes+=1;
		return nbComptes;
	}

}
	
	
	


