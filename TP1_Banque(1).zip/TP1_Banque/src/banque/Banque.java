package banque;

import java.time.LocalDate;

import banque.paiement.Carte;
import util.Date;

public class Banque {
	private int nbClients;
	private Client tabClient[] = new Client[100];
	
	public int ajouterClient(String nom, Date date){
		if(nbClients<100) {
			tabClient[nbClients] = new Client(nom, date);
			nbClients++;
		}
		return nbClients;
	}
	
	public Client getClient(int numero) {
		return this.tabClient[numero];
	}
	
	public void afficherBilan() {
		int i = 0;
		while(i<nbClients) {
			Client client = getClient(i);
			client.afficherBilan();
			i++;
		}
	}
	
	public String genererAutorisation(Carte c, float valeur) {
		Date d = c.getDateValid();
		LocalDate ld = LocalDate.now();
		Date dNow = new Date(ld.getDayOfMonth(), ld.getMonthValue(), ld.getYear());
		if(valeur>1000 || dNow.PosterieurA(d))
			return "OK";
		return "Erreur";
	}
}

	
	


