/**
 * 
 */
package banque.paiement;

import banque.Banque;
import banque.Client;
import banque.Compte;
import util.Date;

/**
 * @author SBF3676A
 *
 */
public class Carte {
	private int code[] = new int[4];
	private int nbTentatives=3;
	private int numeroClient;
	private int numeroCompte;
	private Date date;
	private Banque banque;
	/**
	 * @param code
	 * @param nbTentatives
	 * @param numeroClient
	 * @param numeroCompte
	 */
	public Carte(int[] code, Date date, Banque banque, int numeroClient, int numeroCompte) {
		super();
		this.code = code;
		this.date = date;
		this.banque = banque;
		this.numeroClient = numeroClient;
		this.numeroCompte = numeroCompte;
	}
	
	public Date getDateValid() {
		return this.date;
		
	}
	
	public Banque getBanque() {
		return this.banque;
	}

	/**
	 * @return the nbTentatives
	 */
	public int getNbTentatives() {
		return nbTentatives;
	}
	
	public boolean codeValide(int[] code) {
		return code[0]==this.code[0] && code[1]==this.code[1] && code[2]==this.code[2] && code[3]==this.code[3];
	}
	
	public void payer(Banque b, int numClient, int numCompte, float montant) {
		Compte c1 = banque.getClient(this.numeroClient).getCompte(this.numeroCompte);
		Compte c2 = b.getClient(numClient).getCompte(numCompte);
		c1.retrait(montant);
		c2.depot(montant);

	}
	
}
				
