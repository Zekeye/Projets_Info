package banque.paiement;

import java.util.Scanner;

import banque.Banque;

public class Terminal {
	
	private int numCompte;
	private int numClient;
	/**
	 * @param numCompte
	 * @param numClient
	 */
	public Terminal(Banque b, int numCompte, int numClient) {
		super();
		this.numCompte = numCompte;
		this.numClient = numClient;
	}
	
	public  String payer(float montant, Carte cb, Banque banque, int numClient, int numCompte) {
		Scanner sc = new Scanner(System.in);
		int code[] = new int[4];
		for (int i = 0; i<3 ; i++) {
			System.out.println("Veuillez saisir votre mot de passe à 4 chiffres : ");
			int entier = sc.nextInt();
			for (int j = 3; j >= 0; j--) {
				code[j] = entier%10;
				entier/=10;
			}
			if(cb.codeValide(code)) {
				Banque bank = cb.getBanque();
				if(bank.genererAutorisation(cb, montant).equals("OK")) {
					cb.payer(bank, numClient, numCompte, montant);
					return "OK";
				}
			}
		}
		return "Erreur";
	}
}

